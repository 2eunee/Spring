package org.zerock.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardVO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardMapperTests {

	@Autowired
	BoardMapper mapper;
	
	@Test
	public void testGetList() {
		mapper.getList().forEach(board -> log.info(board));
	}
	
	@Test
	public void testInsert() {
		BoardVO board = new BoardVO();
		board.setTitle("나는야 아이브 장원영");
		board.setContent("내 장점이 뭔지 알아 바로 솔직한 거야");
		board.setWriter("장원영");
		
		mapper.insert(board);
		
		log.info(board);
	}
	
	@Test
	public void testInsertSelectKey() {
		BoardVO board = new BoardVO();
		board.setTitle("나는야 아디들 우기");
		board.setContent("예아 풕킹 톰보이~");
		board.setWriter("우기");
		
		mapper.insertSelectKey(board);
		
		log.info(board);
	}
	
	@Test
	public void testRead() {
		BoardVO board = mapper.read(2562L);
		log.info(board);
	}
	
	@Test
	public void testDelete() {
		log.info("delete : " + mapper.delete(2562L));
	}
	
	@Test
	public void tetUpdate() {
		BoardVO board = new BoardVO();
		board.setTitle("나는야 아이들 우기");
		board.setContent("예아 풕킹 톰보이~");
		board.setWriter("우기");
		board.setBno(2560L);
		
		log.info("update : " + mapper.update(board));
		
	}
	
	
}
