package org.zerock.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.zerock.domain.BoardVO;
import org.zerock.service.BoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;
import oracle.jdbc.proxy.annotation.Post;

@Controller
@RequestMapping("/board/*")
@Log4j
@AllArgsConstructor


//BoardController -> interface BoardService -> interface BoardMapper -> BoardMapper.xml순으로 간다
//최종 BoardMapper.xml를 통해서 데이터베이스로 보내기 때문
public class BoardController {

	private BoardService service;
	
	/*
	private final BoardMapper BoardMapper;
	public BoardController(BoardService boardService,
			boardMapper boardMapper) {
	this.boardService = boardService;
	this.boardMapping = boardMapping;
	*/	
		
	
	
	@GetMapping("/list")
	public void list(Model model) {
		List<BoardVO> list = service.getList();
	
		model.addAttribute("list", list);
		log.info(list);
	}
	
	@PostMapping("/register")
	public String register (BoardVO board, RedirectAttributes rttr) {
		log.info("register : " + board);
		service.register(board);
		rttr.addFlashAttribute("result", board.getBno());
		//addFlashAttribute는 딱 한번만 전송함, 새로고침을 해도 재전송 불가하다
		return "redirect:/board/list"; 
		//"board/list" ==> PRG방식..//포워드방식
	}
	
	@GetMapping("/get")
	public void get(@RequestParam("bno") Long bno, Model model) {
		log.info("/get..");
		model.addAttribute("board", service.get(bno));
		// WEB-INF/Views/board/get.jsp를 찾아간다
	}
	
	@PostMapping("/modify")
	public String modift(BoardVO board, RedirectAttributes rttr) {
		log.info("/modify..");
		
		if(service.modify(board)) { //데이터 수정성공시 result 값을 가져감
			rttr.addFlashAttribute("result", "success");
			
		}
		return "redirect:/board/list"; //PRG방식
		// 성공시 board/list창에 success를 띄어준다
	}

	@PostMapping("/remove")
	public String remove(@RequestParam("bno") Long bno, RedirectAttributes rttr) {
		log.info("remove.." + bno);
		
		if(service.remove(bno)) {
			rttr.addAttribute("result", "success");
		}
		
		return "redirect:/board/list";
	}





}



//getList(); 순서

//board의 list호출
//1. BoardController getList(); 호출되며 
//2. BoardServicelmpl의 List<BoardVO> getList()로 호출함
//3. 호출받은 List<BoardVO>는  public interface BoardMapper public List<BoardVO> getList();를 호출함
//4. BoardMapper.xml의  
//<select id="getList" resultType="org.zerock.domain.BoardVO">
//select * from tbl_board where bno > 0
//</select>
//이 호출되며 sql에서 데이터를 받아와서 public interface BoardMapper public List<BoardVO>에 담음
//5.BoardServicelmpl의 return boardMapper.getList();로 list값을 리턴받아옴
//6.BoardController의 model.addAttribute("list")에 담김
//7.list.jsp에 ${list}에도 담겨있다

